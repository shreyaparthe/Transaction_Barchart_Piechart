import React, { useState, useEffect } from "react";
import axios from "axios";
import "../styles/Statistics.css";

const Statistics = ({ month }) => {
  const [stats, setStats] = useState({ totalSaleAmount: 0, totalSoldItems: 0, totalNotSoldItems: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStatistics();
  }, [month]);

  const fetchStatistics = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`http://localhost:8080/transactions/statistics?month=2`);
      setStats(response.data);
    } catch (error) {
      console.error("Error fetching statistics", error);
      setError("Failed to load statistics");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="statistics">
      <h3>Statistics for Month {month}</h3>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p className="error">{error}</p>
      ) : (
        <div>
          <div>Total Sales Amount: ${stats.totalSaleAmount.toFixed(2)}</div>
          <div>Total Sold Items: {stats.totalSoldItems}</div>
          <div>Total Not Sold Items: {stats.totalNotSoldItems}</div>
        </div>
      )}
    </div>
  );
};

export default Statistics;