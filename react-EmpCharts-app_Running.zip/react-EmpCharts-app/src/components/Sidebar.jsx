import React from "react";
import "../styles/Sidebar.css";


const Sidebar = () => {
  return (
    <div className="sidebar">
      <h2>Dashboard</h2>
      <ul>
        <li>Home</li>
        <li>Transactions</li>
        <li>Statistics</li>
        <li>Charts</li>
      </ul>
    </div>
  );
};

export default Sidebar;
