import React, { useState, useEffect } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import TransactionsTable from "../components/TransactionTable";
import Statistics from "../components/Statistics";
import BarChart from "../components/BarChart";


const Dashboard = () => {
  const [month, setMonth] = useState("March");
  const [search, setSearch] = useState("");
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    fetchTransactions();
  }, [month]);

  const fetchTransactions = async () => {
    try {
      const response = await axios.get(`/api/transactions/search?month=${month}&query=${search}`);
      setTransactions(response.data);
    } catch (error) {
      console.error("Error fetching transactions", error);
    }
  };

  return (
    <div className="dashboard-container">
      <Sidebar />
      <div className="main-content">
        <h1>Transaction Dashboard</h1>
        <div className="controls">
          <input 
            type="text" 
            placeholder="Search transaction" 
            value={search} 
            onChange={(e) => setSearch(e.target.value)}
          />
          <select value={month} onChange={(e) => setMonth(e.target.value)}>
            {["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"].map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
          <button onClick={fetchTransactions}>Search</button>
        </div>
        <Statistics month={month} />
        <TransactionsTable transactions={transactions} />
        <BarChart month={month} />
      </div>
    </div>
  );
};

export default Dashboard;
