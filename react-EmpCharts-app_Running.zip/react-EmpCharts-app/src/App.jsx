import React from "react";
import BarChart from "../src/components/BarChart";
import PieChart from "../src/components/PieChart";
import Statistics from './components/Statistics';
import TransactionTable from "./components/TransactionTable";
const App = () => {
  return (
    <div>
      <BarChart />
      <PieChart></PieChart>
      <Statistics/>
      <TransactionTable/>
    </div>
  );
};

export default App;
